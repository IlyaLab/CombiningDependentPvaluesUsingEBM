### R code from vignette source 'ebmVignette.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: style
###################################################
BiocStyle::latex()


###################################################
### code chunk number 2: sessionInfo
###################################################
toLatex(sessionInfo())


